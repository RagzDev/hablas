---
name: Bug report
about: Create a report to help us improve

---

## 🐛 Bug Report

<!--- Summary description of the bug --->

### Expected behavior

### Reproduction steps

### Configuration

**Version:** 0.1.x

**Platform:** 
- [ ] :iphone: iOS
- [ ] :robot: Android
