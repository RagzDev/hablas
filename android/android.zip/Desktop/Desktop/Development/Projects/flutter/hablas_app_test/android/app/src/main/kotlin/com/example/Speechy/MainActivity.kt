package com.example.Speechy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
