package com.RagzDev.hablas_app_test

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
